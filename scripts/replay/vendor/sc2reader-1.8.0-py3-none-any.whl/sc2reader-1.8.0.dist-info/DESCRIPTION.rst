.. image:: https://zenodo.org/badge/DOI/10.5281/zenodo.4007376.svg
   :target: https://doi.org/10.5281/zenodo.4007376

What is sc2reader?
====================

sc2reader is a python library for extracting information from various different Starcraft II resources. These resources currently include Replays, Maps, and Game Summaries; we have plans to add support for Battle.net profiles and would gladly accept adapters to the more entrenched SCII sites such as sc2ranks.

There is a pressing need in the SC2 community for better statistics, better analytics, better tools for organizing and searching replays. Better websites for sharing replays and hosting tournaments. These tools can't be created without first being able to open up Starcraft II game files and analyze the data within. Our goal is to give anyone and everyone the power to construct their own tools, do their own analysis, and hack on their own Starcraft II projects under the open MIT license.


Who Uses sc2reader?
======================

sc2reader is currently powering:

* Websites: `gggreplays.com`_, `gamereplays.org`_, `spawningtool.com`_
* Tools: `The Core`_
* Experiments: `Midi Conversion`_

If you use sc2reader and you would like your tool, site, project, or implementation listed above, drop us a line on our `mailing list`_.


.. _gggreplays.com: http://gggreplays.com
.. _gamereplays.org: http://www.gamereplays.org/starcraft2/
.. _spawningtool.com: https://lotv.spawningtool.com
.. _The Core: http://www.teamliquid.net/forum/viewmessage.php?topic_id=341878
.. _Midi Conversion: https://github.com/obohrer/sc2midi


Current Status
=================

sc2reader is production ready at release and under active development on Github. It is currently capable of parsing varying levels of information out of the three primary resource types listed below. For a more detailed and exact description of the information that can be extracted please consult the `documentation`_ hosted on ReadTheDocs.

.. _documentation: http://sc2reader.rtfd.org/


Replays
-------------

Replays can be parsed for the following general types of information:

- Replay details (map, length, version, expansion, datetime, game type/speed, ...)
- Player details (name, race, team, color, bnet url, win/loss, ...)
- Message details (text, time, player, target, pings, ...)
- Unit Selection and Hotkey (Control Group) events.
- Resource Transfers and Requests (but not collection rate or unspent totals!)
- Unfiltered Unit commands (attack, move, train, build, psi storm, etc)
- Camera Movements for all players and observers.

Replays from release 2.0.8 onward make additional state information available:

- Unit states - creation time, positions, and deaths times
- Player resource stats - collection rates/unspent totals
- Player spending stats - resources spent and lost

Further game state information can be extracted from this raw information:

- All unit selections and hotkey values for every frame of the game.
- APM/EPM and its untold variations.
- Supply counts, expansion timings, build orders, etc

We have data dictionaries in place for standard games that make unit meta data
available.  Unit meta data is currently limited to:

- Costs - mineral, vespene, supply
- Classification - army, building, worker

Additionally, abilities that create units/buildings have the built unit linked
with the build time in game seconds.

Unfortunately this information IS NOT currently versioned and is only accurate
for the latest builds of Starcraft. Versioned meta data support will be added
in future releases.


Maps
-------

Maps can be parsed for the following information:

* Minimap and Icon images (tga format)
* enUS localized Name, Author, Description, Website (if available)
* Map Dimensions, Camera Bounds, Tileset
* Player Slot data and Advanced Teams alliance/enemy data.

There is a lot more in here to be had for the adventurous.


Game Summaries
-----------------

Game Summary files are downloaded by the client in order to allow you to view the game summary from your match history. Prior to 2.0.8 they were the only way to get the information from the summary screen. Since the 2.0.8 release you have been able to compute this information yourself from the replay files.

Thank you Prillan and `Team Liquid`_ for helping to decode this file.

* Lobby Properties (game speed, game type, ...)
* Player Information (Race, Team, Result, bnet info, ...)
* Player Graphs & Stats (Army Graph, Income Graph, Avg Unspent Resources, ...)
* URLs to map localization files and images
* Player build orders up to 64 (real) actions

Parsing on these files is now production ready for those that can get them. See the `Team Liquid`_ thread for details on how to go about getting them.

Again, these files are generally unnecessary after the 2.0.8 release.

.. _Team Liquid: http://www.teamliquid.net/forum/viewmessage.php?topic_id=330926


Basic Usage
=====================

..note::

    For example scripts, checkout the docs and the `sc2reader.scripts`_ package on Github or in the source.


Loading Replays
-------------------
For many users, the most basic commands will handle all of their needs::

    import sc2reader
    replay = sc2reader.load_replay('MyReplay', load_map=true)

This will load all replay data and fix GameHeart games. In some cases, you don't need the full extent of the replay data. You can use the load level option to limit replay loading and improve load times::

    # Release version and game length info. Nothing else
    sc2reader.load_replay('MyReplay.SC2Replay', load_level=0)

    # Also loads game details: map, speed, time played, etc
    sc2reader.load_replay('MyReplay.SC2Replay', load_level=1)

    # Also loads players and chat events:
    sc2reader.load_replay('MyReplay.SC2Replay', load_level=2)

    # Also loads tracker events:
    sc2reader.load_replay('MyReplay.SC2Replay', load_level=3)

    # Also loads game events:
    sc2reader.load_replay('MyReplay.SC2Replay', load_level=4)

If you want to load a collection of replays, you can use the plural form. Loading resources in this way returns a replay generator::

    replays = sc2reader.load_replays('path/to/replay/directory')

.. _sc2reader.scripts: https://github.com/ggtracker/sc2reader/tree/upstream/sc2reader/scripts


Loading Maps
----------------

If you have a replay and want the map file as well, sc2reader can download the corresponding map file and load it in one of two ways::

    replay = sc2reader.load_replay('MyReplay.SC2Replay', load_map=true)
    replay.load_map()

If you are looking to only handle maps you can use the map specific load methods::

    map = sc2reader.load_map('MyMap.SC2Map')
    map = sc2reader.load_maps('path/to/maps/directory')


Using the Cache
---------------------

If you are loading a lot of remote resources, you'll want to enable caching for sc2reader. Caching can be configured with the following environment variables:

* SC2READER_CACHE_DIR - Enables caching to file at the specified directory.
* SC2READER_CACHE_MAX_SIZE - Enables memory caching of resources with a maximum number of entries; not based on memory imprint!

You can set these from inside your script with the following code **BEFORE** importing the sc2reader module::

    os.environ['SC2READER_CACHE_DIR'] = "path/to/local/cache"
    os.environ['SC2READER_CACHE_MAX_SIZE'] = 100

    # if you have imported sc2reader anywhere already this won't work
    import sc2reader


Using Plugins
------------------

There are a growing number of community generated plugins that you can take advantage of in your project. See the article on `Creating GameEngine Plugins`_ for details on creating your own. To use these plugins you need to customize the game engine::

    from sc2reader.engine.plugins import SelectionTracker, APMTracker
    sc2reader.engine.register_plugin(SelectionTracker())
    sc2reader.engine.register_plugin(APMTracker())

The new GameHeartNormalizerplugin is registered by default.

.. _Creating GameEngine Plugins: http://sc2reader.readthedocs.org/en/latest/articles/creatingagameengineplugin.html


Installation
================

sc2reader runs on any system with Python 2.6+, 3.2+, or PyPy installed.


From PyPI (stable)
---------------------

Install from the latest release on PyPI with pip::

    pip install sc2reader

or easy_install::

    easy_install sc2reader

or with setuptools (specify a valid x.x.x)::

    wget http://pypi.python.org/packages/source/s/sc2reader/sc2reader-x.x.x.tar.gz
    tar -xzf sc2reader-x.x.x.tar.gz
    cd sc2reader-x.x.x
    python setup.py install

Releases to PyPi can be very delayed (sorry!), for the latest and greatest you are encouraged to install from Github upstream.


From Github
--------------------------

Github upstream is generally stable with development branches more unstable.

We use `circle-ci`_ to provide a record of our `continuous testing`_. Please verify that tests are passing before installing development versions.

Install from the latest source on Github with pip::

    pip install -e git+git://github.com/ggtracker/sc2reader#egg=sc2reader

or with setuptools::

    wget -O sc2reader-upstream.tar.gz https://github.com/ggtracker/sc2reader/tarball/upstream
    tar -xzf sc2reader-upstream.tar.gz
    cd sc2reader-upstream
    python setup.py install

.. _circle-ci: https://circleci.com/
.. _coveralls.io: https://coveralls.io
.. _test coverage: https://coveralls.io/r/GraylinKim/sc2reader
.. _continuous testing: https://circleci.com/gh/ggtracker/sc2reader


For Contributors
-------------------

Contributors should install from an active git repository using setuptools in `develop`_ mode. This will install links to the live code so that local edits are available to external modules automatically::

    git clone https://github.com/ggtracker/sc2reader.git
    cd sc2reader
    python setup.py develop

Please review the `CONTRIBUTING.md`_ file and get in touch with us before doing too much work. It'll make everyone happier in the long run.

.. _develop: http://peak.telecommunity.com/DevCenter/setuptools#development-mode
.. _CONTRIBUTING.md: https://github.com/ggtracker/sc2reader/blob/upstream/CONTRIBUTING.md


Testing
-------------------

We use ``pytest`` for testing. If you don't have it just ``pip install pytest``.

To run the tests, just do::

    pytest


When repeatedly running tests it can be very helpful to make sure you've set a local cache directory to prevent long fetch times from battle.net.
So make some local cache folder::

    mkdir cache

And then run the tests like this::

    SC2READER_CACHE_DIR=./cache pytest

To run just one test:

    SC2READER_CACHE_DIR=./cache pytest test_replays/test_replays.py::TestReplays::test_38749

If you'd like to see which are the 10 slowest tests (to find performance issues maybe)::

    pytest --durations=10

If you want ``pytest`` to stop after the first failing test::

    pytest -x


Have a look at the very fine ``pytest`` docs for more information.

Good luck, have fun!


Community
==============

sc2reader has a small but growing community of people looking to make tools and websites with Starcraft II data. If that sounds like something you'd like to be a part of please join our underused `mailing list`_ and start a conversation or stop by #sc2reader on FreeNode and say 'Hi'. We have members from all over Europe, Australia, and the United States currently, so regardless of the time, you can probably find someone to talk to.


Issues and Support
=====================

We have an `issue tracker`_ on Github that all bug reports and feature requests should be directed to. We have a `mailing list`_ with Google Groups that you can use to reach out for support. We are generally on FreeNode in the #sc2reader and can generally provide live support and address issues there as well.

.. _mailing list: http://groups.google.com/group/sc2reader
.. _issue tracker: https://github.com/ggtracker/sc2reader/issues


Acknowledgements
=======================

Thanks to all the awesome developers in the SC2 community that helped out
and kept this project going.

* Special thanks to the people of the awesome (but abandoned!) `phpsc2replay`_
  project whose public documentation and source code made starting this library
  possible.
* Thanks to `sc2replay-csharp`_ for setting us straight on game events parsing
  and assisting with our v1.5 upgrade.
* Thanks to `ggtracker.com`_ for sponsoring further development and providing
  the thousands of test files used while adding s2gs and HotS support.
* Thanks to Blizzard for supporting development of 3rd party tools and releasing
  their `s2protocol`_ full reference implementation.


.. _ggtracker.com: http://ggtracker.com
.. _phpsc2replay: http://code.google.com/p/phpsc2replay/
.. _sc2replay-csharp: https://github.com/ascendedguard/sc2replay-csharp
.. _s2protocol: https://github.com/Blizzard/s2protocol



CHANGELOG
============

1.8.0 - May 4, 2022
-------------------
* Fix various typos in docs #146
* Fix various URLs for blizzard resources #151 #154 #156
* Fix Ravager data #161
* Add CommandManagerStateEvent #162
* Fix participant state from gameheart #171


1.7.0 - May 17, 2021
--------------------
* Add DOI to the README #128
* Add various missing attributes for co-op replays #129
* Add support for python 3.8, 3.9 #132 #136
* Fix owner on an event with no unit #133
* Add support for ResourceTradeEvent #135
* Fix depot URL template #139

1.6.0 - July 30, 2020
---------------------
* Add support for protocol 80949 (StarCraft 5.0) #122
* Fix toJson script #118

1.5.0 - January 18, 2020
------------------------
* Add support for protocol 77379 #106 #107
* Workaround for missing data #102 #104

1.4.0 - August 19, 2019
-----------------------
* Add support for protocol 75689 #95

1.3.2 - August 9, 2019
----------------------
* Allow pytest #84
* Format code with black #87
* Fix UnitTypeChangeEvent.__str__ #92
* Add Stetmann #93

1.3.1 - November 29, 2018
-------------------------
* Parse backup if data is missing #69

1.3.0 - November 16, 2018
-------------------------
* Added support for protocol 70154 (StarCraft 4.7.0)
* Added support for Zeratul
* Updated CircleCI build for Python 3.7
* Fixed a bug with printing TrackerEvent

1.2.0 - October 7, 2018
-----------------------
* Added support for Tychus
* Verified that StarCraft 4.6.1 replays work

1.1.0 - June 26, 2018
---------------------
* Added support for protocol 65895 (StarCraft 4.4.0)

1.0.0 - May 18, 2018
--------------------
* Added support for protocol 48258 through 64469
* Update game data and scripts for generating game data
* Fix ggtracker/sc2reader CircleCI build for python 3
* Added support for parsing Co-op replays

0.8.0 - December 16, 2016
---------------------------
* Merged into ggtracker/sc2reader, which mostly means that we have a bunch of parsing fixes.  Thanks @StoicLoofah!

0.7.0 -
---------------------------

* Deprecated unit.killed_by in favor of unit.killing_player
* Added unit.killed_units
* Added unit.killing_unit
* Added UnitDiedEvent.killing_player
* Added UnitDiedEvent.killing_unit
* Deprecated UnitDiedEvent.killer_pid in favor of UnitDiedEvent.killing_player_id
* Deprecated UnitDiedEvent.killer in favor of UnitDiedEvent.killing_player
* Use generic UnitType and Ability classes for data. This means no more unit._type_class.__class__.__name__. But hopefully people were not doing that anyway.
* Now a CorruptTrackerFileError is raised when the tracker file is corrupted (generally only older resume_from_replay replays)
* Removed the defunct replay.player_names attribute.
* Removed the defunct replay.events_by_type attribute.
* Removed the defunct replay.other_people attribute.
* Replays can now be pickled and stored for later consumption.
* All references to the gateway attribute have been replaced in favor of region; e.g. replay.region
* Use generic UnitType and Ability classes for data. This means no more unit._type_class.__class__.__name__. But hopefully people were not doing that anyway.
* Now a CorruptTrackerFileError is raised when the tracker file is corrupted (generally only older resume_from_replay replays)
* Added replay.resume_from_replay flag. See replay.resume_user_info for additional info.
* PacketEvent is now ProgressEvent.
* SetToHotkeyEvent is now SetControlGroupEvent.
* AddToHotkeyEvent is now AddToControlGroupEvent.
* GetFromHotkeyEvent is now GetControlGroupEvent.
* PlayerAbilityEvent is no longer part of the event hierarchy.
* AbilityEvent doubled as both an abstract and concrete class (very bad, see #160). Now split into:
   * AbilityEvent is now CommandEvent
   * AbilityEvent is now BasicCommandEvent
* TargetAbilityEvent is now TargetUnitCommandEvent
* LocationAbilityEvent is now TargetPointCommandEvent
* SelfAbilityEvent is now DataCommandEvent
* Removed the defunct replay.player_names attribute.
* Removed the defunct replay.events_by_type attribute.
* Removed the defunct replay.other_people attribute.

* event.name is no longer a class property; it can only be accessed from an event instance.
* PingEvents now have new attributes:
   * event.to_all - true if ping seen by all
   * event.to_allies - true if ping seen by allies
   * event.to_observers - true if ping seen by observers
   * event.location - tuple of (event.x, event.y)


0.6.4 - September 22nd 2013
---------------------------

* Fix bug in code for logging errors.
* Fix siege tank supply count.
* Small improvements to message.events parsing.

0.6.3 - September 15th 2013
---------------------------

* Properly mark hallucinated units.

0.6.2 - September 5th 2013
--------------------------
* Fix rare bug where TargetedAbility events could overwrite unit types.
* Substantial performance boost (20% in local testing)
* Fixed serious bug with FileCaching that affected Python3 users.
* Plugins can now yield PluginExit events to broadcast their shutdown.

0.6.1 - August 13th 2013
------------------------

* Fix bug in event ordering that caused game events to process before tracker events.
* Fix APMTracker to count APM for all humans, not just players.

0.6.0 - August 12th 2013
------------------------

New Stuff:
~~~~~~~~~~~~~~~~

* Adds python 3.2+ support
* Adds support for patch 2.0.10.
* Adds experimental SC2Map.MapInfo parsing support.
* Implements new replay GameEngine and plugin support.
* Added a sc2json script contributed by @ChrisLundquist
* Adds plugin GameHeartNormalizer plugin by @StoicLoofah
* Hooked up coveralls.io for coverage reporting: https://coveralls.io/r/GraylinKim/sc2reader
* Hooked up travis-ci for continuous testing: https://travis-ci.org/GraylinKim/sc2reader
* Switched to built in python unittest module for testing.

Changed Stuff (non-backwards compatible!):
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

* Summary.teams is now summary.team; summary.team is now summary.teams. To conform with replay name conventions
* Fixed #136, unit types from tracker events are used when available.
* Deprecated player.gateway for player.region
* Reorganized the person/player/observer hierarchy. Top level classes are now Computer, Participant, and Observer. Participant and Computer are both children of player so any isinstance code should still work fine.
* Player.uid now means something completely different! Use player.toon_id instead
* Player.uid is now the user id of the player (was player.cid)
* PersonDict can no longer be constructed from a player list and new players cannot be added by string (name). Only integer keys accepted for setting.
* Log a warning instead of throwing an exception when using an unknown colors.
   * An unknown hex value will use the hex value as the name.
   * An unknown color name will use 0x000000 as the color.
* Finally straighten out all these replay player list/dicts
   * human/humans -> human entities, indexed by uid
   * computer/computers -> computer entities, indexed by pid
   * player/players -> actually playing in the game, indexed by pid
   * observer/observers -> observing the game, indexed by uid
   * entities -> players + observers || humans + computers, indexed by pid
   * client/clients - (deprecated) same as human/humans
   * people/person - (deprecated) same as entity/entities


0.5.1 - June 1, 2013
--------------------

* Fixes several game event parsing issues for older replays.
* Properly maps ability ids for armory vehicle & ship armor upgrades.
* Uses the US depot for SEA battle.net depot dependencies.
* ``PlayerStatEvent.food_used`` and ``food_made`` are now properly divided by 4096
* ``AbilityEvent.flags`` are now processed into a dictionary mapping flag name to True/False (``AbilityEvent.flag``)
* Fixed error preventing UnitOwnerChangeEvents from being processed
* Fixed the toJSON plugin and adds new fields
* Fixed error preventing parsing of MapHeader (s2mh) files
* APMTracker now properly calculates average APM to the last second played by each player instead of using the number of replay minutes in the denominator.

0.5.0 - May 7, 2013
--------------------

* Support for all replays (arcade replays now parse!) from all versions
* Support for the new replay.tracker.events added in 2.0.8
   * Units now have birth frame, death frame, and owner information
   * New events for (roughly) tracking unit positions
   * New events for tracking player resource stockpiles and collection rates
   * More!
* Much more comprehensive documentation.
* New unit model
   * SiegeTank and SiegeTankSieged (and others with different forms) are no longer separate units.
   * Units that can transform maintain a full type history.
   * Units are correctly and uniquely identified by unit_id alone.
* Updated unit meta data:
   * Mineral Cost
   * Vespene Cost
   * Supply Cost
   * Flags for is_worker, is_army, is_building
* Added ability meta data:
   * is_build flag marking abilities that create units
   * build_unit indicating the unit type that is built
   * build_time indicating the build time for the ability



